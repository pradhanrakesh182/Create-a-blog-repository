const form = document.querySelector('#contact-form');
const popup = document.querySelector('.popup');
const popupContent = document.querySelector('.popup-content');

form.addEventListener('submit', e => {
  e.preventDefault();
  const name = form.elements['name'].value;
  const email = form.elements['email'].value;
  const message = form.elements['message'].value;
  popupContent.innerHTML = `<h2>Thank You!</h2><p>${name}, your message has been sent. We will get back to you shortly.</p>`;
  popup.classList.add('show-popup');
  form.reset();
  setTimeout(() => {
    popup.classList.remove('show-popup');
    window.location.href = "index.html";
  },3000);
});
